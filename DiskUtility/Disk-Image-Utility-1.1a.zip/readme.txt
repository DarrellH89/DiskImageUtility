The CFG files are for a Flash Floppy Gotek. 

Using this confioguration, DOS images end oin DOS.IMG and CP/M images simple end in IMG.